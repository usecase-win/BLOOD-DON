# 🩸 Blood Donation Management System
### DBMS Mini Project — Node.js + Express + MySQL

---

## 📁 Folder Structure

```
blood-donation-system/
│
├── server.js           ← Backend (Node.js + Express + MySQL)
├── package.json        ← Project dependencies
├── setup.sql           ← Run this in MySQL to create DB & table
│
└── public/
    └── index.html      ← Frontend (HTML + CSS + JavaScript)
```

---

## ⚙️ Prerequisites

1. **Node.js** — https://nodejs.org (LTS version)
2. **MySQL** — https://dev.mysql.com/downloads/installer/
   - Install MySQL Community Server + MySQL Workbench

---

## 🚀 Step-by-Step Setup

### Step 1 — Set Up the Database (Do this ONCE)

Open **MySQL Workbench** (or MySQL CLI) and run the `setup.sql` file:
```sql
-- Either open setup.sql in Workbench and click Run
-- Or paste these commands manually:

CREATE DATABASE IF NOT EXISTS bloodDonationDB;
USE bloodDonationDB;
CREATE TABLE IF NOT EXISTS donors (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  age        INT          NOT NULL,
  bloodGroup VARCHAR(5)   NOT NULL,
  city       VARCHAR(100) NOT NULL,
  contact    VARCHAR(15)  NOT NULL
);
```

### Step 2 — Update Your MySQL Password in server.js

Open `server.js` and find this section:
```js
const db = mysql.createConnection({
  host:     'localhost',
  user:     'root',
  password: '',       // ← put your MySQL root password here
  database: 'bloodDonationDB'
});
```

### Step 3 — Install Dependencies
```
npm install
```

### Step 4 — Start the Server
```
node server.js
```
You should see:
```
✅ Connected to MySQL database successfully!
🚀 Server running at http://localhost:3000
```

### Step 5 — Open the App
```
http://localhost:3000
```

---

## 🌐 API Endpoints

| Method | URL | Purpose | SQL Used |
|--------|-----|---------|----------|
| POST | `/add-donor` | Add new donor | `INSERT INTO donors` |
| GET | `/search-donor?bloodGroup=A+&city=Mumbai` | Search donors | `SELECT * FROM donors WHERE ...` |

---

## 🗄️ Database Details

- **Database**: `bloodDonationDB`
- **Table**: `donors`

| Column | Data Type | Description |
|--------|-----------|-------------|
| id | INT AUTO_INCREMENT PK | Unique donor ID (auto) |
| name | VARCHAR(100) | Donor's full name |
| age | INT | Donor's age |
| bloodGroup | VARCHAR(5) | e.g., A+, O-, B+ |
| city | VARCHAR(100) | City of donor |
| contact | VARCHAR(15) | Mobile number |

---

## 📝 Viva Preparation — Key DBMS Concepts

### Q1. What database did you use and why?
**MySQL** — a Relational Database Management System (RDBMS). Data is stored in structured tables with rows and columns, and uses SQL (Structured Query Language) to manage data.

### Q2. What is a Table? What is a Schema?
A **table** stores data in rows and columns (like Excel).
A **schema** is the structure — which columns exist, what data types they hold, and constraints like NOT NULL or PRIMARY KEY.

### Q3. What is a Primary Key?
The `id` column is the **Primary Key** — it uniquely identifies each donor record. We used `AUTO_INCREMENT` so MySQL assigns it automatically.

### Q4. Which SQL queries did you use?
- `CREATE DATABASE` — creates the database
- `CREATE TABLE` — defines the donors table structure
- `INSERT INTO` — adds a new donor (triggered by POST /add-donor)
- `SELECT * FROM donors WHERE ...` — searches donors (triggered by GET /search-donor)

### Q5. What is a parameterized query? Why did you use it?
We use `?` placeholders in SQL queries instead of directly inserting user input:
```js
db.query('INSERT INTO donors VALUES (?, ?, ?, ?, ?)', [name, age, ...])
```
This prevents **SQL Injection** attacks — a major security concept in DBMS.

### Q6. What is LIKE in SQL?
`LIKE '%mumbai%'` is used for **partial/pattern matching** in text columns.
It finds any city that *contains* the word "mumbai", regardless of case or position.

### Q7. What is `WHERE 1=1`? Why did you use it?
It's a trick to make **dynamic queries** easier. Since `1=1` is always true, we can safely append `AND bloodGroup = ?` or `AND city LIKE ?` only when those values are provided, without worrying about SQL syntax errors.

### Q8. What is the difference between SQL and NoSQL?
| SQL (MySQL) | NoSQL (MongoDB) |
|-------------|----------------|
| Tables & Rows | Collections & Documents |
| Fixed schema | Flexible schema |
| Uses SQL language | Uses JSON-like queries |
| Relational | Non-relational |
| Great for structured data | Great for unstructured data |

### Q9. What is mysql2 package?
`mysql2` is a Node.js library (npm package) that lets JavaScript code connect to and query a MySQL database.

### Q10. What is Express.js?
A lightweight **Node.js web framework** used to create HTTP routes (POST, GET) and serve our HTML frontend file.

---

## 🔧 Technologies Used

| Technology | Purpose |
|------------|---------|
| HTML + CSS | Frontend UI |
| JavaScript (Fetch API) | Sending HTTP requests from browser |
| Node.js | Backend JavaScript runtime |
| Express.js | Web framework / API routes |
| mysql2 | Node.js MySQL driver |
| MySQL | Relational database (stores donor data) |

---

*Blood Donation Management System — DBMS Mini Project*
